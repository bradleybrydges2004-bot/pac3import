Civil Networks PAC3 — Generic Fantasy Monk local test archive

This is an UNTESTED, simplified Source model package extracted from a user-supplied workshop .gma for personal testing. It is NOT a separate robe-only asset. Wearing this full character model over another playermodel may cover its face/body. Bonemerge compatibility is unknown.

One robe texture and one boot texture are retained to keep archive size below 15 MB. Original normal maps and alternative colour textures were omitted; .vmt materials were adjusted to reference the included textures, so visual quality / skins may differ from the original addon.

Original model path: models/players/an_cc_monk.mdl

To TEST LOCALLY in GMod: extract this archive contents into garrysmod/ (models/ and materials/ at the root); PAC3 editor -> add a Model part -> set Model to models/players/an_cc_monk.mdl -> try Bone Merge. This does not guarantee an appropriate wearable robe.

For Civil Networks Github import the guide requires ZIP format with 0 Store compression, <15 MB, public repository and a raw ZIP URL entered into a Model part. Before publishing these third-party assets publicly, obtain the creator's permission to redistribute them. This archive has NOT been uploaded to GitHub.

Source addon: https://steamcommunity.com/sharedfiles/filedetails/?id=2333041067
Civil Networks guide: https://civilnetworks.net/community/threads/pac3-importing-guide-github.34573/
